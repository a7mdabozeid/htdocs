<?php
/*Template Name:By Abozeid*/
/**
 * Page template
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Razzi
 */

get_header();
?>





<html>
<head>
<!-- Meta Tags -->
 <meta charset="utf-8">
<!-- Mobile Meta -->
 <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0">
  <title>Home</title>
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"> -->

  <!-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> -->

  <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBdodiLO598_RD8_NYXK7nBKNA9Fhx_uBQ&language=ar&libraries=places,geometry&.js"></script>
</head>
<body>

<style>
      .map{
      	direction: rtl;
        background: #F8F8F8;
        border:2px solid rgb(29 35 39);
        height: 400px;
        width: 100%;
				margin-bottom: 20px;
				margin-top: 20px;
       }

      .text-center{
        text-align: center;
      }
      .text-right{
          text-align: right;
          direction: rtl;
          float: right;
      }

      select.form-control {
        font-size:14px !important;
        height: auto;
      }

      @media only screen and (max-width: 760px) {
        .map{
            /* display: block; */
            margin-top:50px;
            /* overflow:visible !important; */
          }

          .site-wrapper > .container > .row{
            display: block;
          }


      }
</style>

<div class="container">
  <div class="row">

    <div class="col-sm-12" style="direction:rtl">
      <form>
           <div class=" input-group col-sm-6 ">
              <label for="disabledSelect" class="form-label00">الدولة</label>

						   <select id="disabledSelect" class="form-control Country ">
                 <option value="Saudia Arabia">المملكة العربية السعودية</option>
               </select>

               <label class="form-label">المدينة</label>
                 <select class="form-control Cities">
                   <option value="" selected="selected"></option>
                   <option value="Riyadh" selected>Riyadh </option>
                   <option value="Jeddah">Jeddah </option>
                </select>
           </div>
       </form>


    </div>

    <div class="col-sm-8"  >
      <div id="mapCanvas" class="map"></div>
    </div>

  </div>
</div>



<script>

(function initMap($) {
    var map;
    var bounds = new google.maps.LatLngBounds();
		var latitude = document.getElementsByName('latitude').value;
		var longitude = document.getElementsByName('longitude').value;

    // var latitude = $('input[name="latitude"]').val();
    // var longitude = $('input[name="longitude"]').val();
		var lat = (latitude ? latitude : 21.543333);
     var lng = (longitude ? longitude : 39.172779);
    var latlng = new google.maps.LatLng(lat,lng);
   var image =  "https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png";

    var mapOptions = {
        mapTypeId: 'roadmap'
    };

    // Display a map on the web page
    map = new google.maps.Map(document.getElementById("mapCanvas"), mapOptions);
    map.setTilt(20);

    // Multiple markers location, latitude, and longitude
    var markers = [
        ['Riyadh, SA', 24.774265,46.738586],
        ['Jeddah, SA', 21.543333,39.172779],
      ];

    // Info window content
    var infoWindowContent = [
        ['<div class="info_content">' +
        '<h4 class="text-center">Riyadh</h4>' +
        '</div>' ],

        [ '<div class="info_content">' +
        '<h4 class="text-center">Jeddah</h4>' +
        '</div>'],

    ];

    // Add multiple markers to map
    var infoWindow = new google.maps.InfoWindow(), marker, i;

    // Place each marker on the map
    for( i = 0; i < markers.length; i++ ) {
        var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
        bounds.extend(position);
        marker = new google.maps.Marker({
            position: position,
            map: map,
            title: markers[i][0],
            icon: image,

        });

        // Add info window to marker
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
                infoWindow.setContent(infoWindowContent[i][0]);
                infoWindow.open(map, marker);
                infoWindow.setIcon(image);

            }
        })(marker, i));

        // Center the map to fit all markers on the screen
        map.fitBounds(bounds);





        var geocoder = new google.maps.Geocoder();

        function search(address) {
            geocoder.geocode({
              'address': address
            }, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                  map.setCenter(results[0].geometry.location);
                  var marker = new google.maps.Marker({
                    map: map,
                    position: markers[i][1].geometry.location,
                    icon: image,

                  });
                } else {
                  alert('Geocode was not successful for the following reason: ' + status);
                }
            });
        }


    }


      /*      var marker = new google.maps.Marker({
                position: latlng,
                map: map,
                icon: image,
                draggable: true,
                animation: google.maps.Animation.DROP
            });*/

    // Set zoom level
    var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
        this.setZoom(6);
        google.maps.event.removeListener(boundsListener);
    });


// ::::::::::::::::::::::::::::
/*
var input = document.getElementById('searchTextField');
var autocomplete = new google.maps.places.Autocomplete(input, {
    types: ["geocode"]
});

autocomplete.bindTo('bounds', map);
var infowindow = new google.maps.InfoWindow();
/*
google.maps.event.addListener(autocomplete, 'place_changed', function(event) {
    infowindow.close();
    var place = autocomplete.getPlace();
    if (place.geometry.viewport) {
        map.fitBounds(place.geometry.viewport);
    } else {
        map.setCenter(place.geometry.location);
        map.setZoom(17);
    }

    moveMarker(place.name, place.geometry.location);
    $('.MapLat').val(place.geometry.location.lat());
    $('.MapLon').val(place.geometry.location.lng());
});
google.maps.event.addListener(marker, 'dragend', function(event) {
    $('.MapLat').val(event.latLng.lat());
    $('.MapLon').val(event.latLng.lng());
    $("#searchTextField").val('');
});
/*google.maps.event.addListener(map, 'click', function(event) {
    $('.MapLat').val(event.latLng.lat());
    $('.MapLon').val(event.latLng.lng());
    infowindow.close();
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({
        "latLng": event.latLng
    }, function(results, status) {
        console.log(results, status);
        if (status == google.maps.GeocoderStatus.OK) {
            console.log(results);
            var lat = results[0].geometry.location.lat(),
                lng = results[0].geometry.location.lng(),
                placeName = results[0].address_components[0].long_name,
                latlng = new google.maps.LatLng(lat, lng);

            moveMarker(placeName, latlng);
            $("#searchTextField").val(results[0].formatted_address);
        }
    });
});*/
/*
function moveMarker(placeName, latlng) {
    marker.setIcon(image);
    marker.setPosition(latlng);
    infowindow.setContent(placeName);
}
*/
$('select,input').change(function() {
var searchString = [$('select.Country').val(), $('select.Cities').val(), $('input#SearchDistrict').val()].join(', ');
// alert(searchString);
search(searchString);

});


})(jQuery);




// Load initialize function
google.maps.event.addDomListener(window, 'load', initMap);
</script>







</body>
</html>


<?php //get_sidebar();?>
<?php //} ?>
<?php get_footer();  ?>
