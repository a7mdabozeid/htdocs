<?php
/**
 * Customer invoice email
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/customer-invoice.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates\Emails
 * @version 3.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$order_data = $order->get_data() ;
/**
 * Executes the e-mail header.
 *
 * @hooked WC_Emails::email_header() Output the email header
 */
do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<?php /* translators: %s: Customer first name */ ?>
    <p><?php printf( esc_html__( 'Hi %s,', 'woocommerce' ), esc_html( $order->get_billing_first_name() ) ); ?></p>

<?php if ( $order->needs_payment() ) { ?>
    <p>
        <?php
        printf(
            wp_kses(
            /* translators: %1$s Site title, %2$s Order pay link */
                __( 'An order has been created for you on %1$s. Your invoice is below, with a link to make payment when you’re ready: %2$s', 'woocommerce' ),
                array(
                    'a' => array(
                        'href' => array(),
                    ),
                )
            ),
            esc_html( get_bloginfo( 'name', 'display' ) ),
            '<a href="' . esc_url( $order->get_checkout_payment_url() ) . '">' . esc_html__( 'Pay for this order', 'woocommerce' ) . '</a>'
        );
        ?>
    </p>

<?php } else { ?>
    <p>
        <?php
        /* translators: %s Order date */
        printf( esc_html__( 'Here are the details of your order placed on %s:', 'woocommerce' ), esc_html( wc_format_datetime( $order->get_date_created() ) ) );
        ?>
    </p>
    <?php
}





?>
    <div class="container">


        <div class="header">
            <div class="brand">
                <div>
                    <img src="https://sedco.com/wp-content/uploads/2019/03/Alshiaka1.jpg" alt="logo">
                </div>
                <div>
                    <img
                            src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/QR_code_for_mobile_English_Wikipedia.svg/1200px-QR_code_for_mobile_English_Wikipedia.svg.png"
                            alt="qrcode">
                </div>
                <div>
                    <h4> <?php __('Tax nummber' , 'shiaka-emails') ?> </h4>
                    <p>0000000000000</p>
                </div>
            </div>

            <div class="info">
                <span><?= __("رقم الفاتروة" , 'shiaka-emails') ?> </span>
                <span><?= $order->get_order_number() ?></span>
                <span><?= __('تاريخ الفاتورة' , 'shiaka-emails') ?></span>
                <span><?=  $order->get_date_created()->date('Y/m/d'); ?></span>
            </div>
        </div>
        <div class="content-body">
            <div class="col client">
                <h4><?= __('Customer information' , 'shiaka-email') ?></h4>
                <p>
                    <span><?= __("Customer ") ?></span>
                    <span><?= $order->get_billing_first_name() . ' ' .$order->get_billing_last_name() ?></span>
                </p>

                <p>

                    <span><?= __('Phone' , 'shiaka-emails') ?></span>
                    <span><?= $order_data['billing']['phone'] ?></span>
                </p>
                <p>
                    <span><?= __('Email' , 'shiaka-emails') ?></span>
                    <span><?= $order_data['billing']['email'] ?></span>
                </p>
                <p>
                    <span><?= __('Country' , 'shiaka-emails') ?></span>
                    <span><?= $order_data['billing']['country'] ?></span>
                </p>
                <p>
                    <span><?= __('Area' , 'shiaka-emails') ?></span>
                    <span><?= $order_data['billing']['address_1'] ?></span>
                </p>
                <p>
                    <span><?= __('City' , 'shiaka-emails') ?></span>
                    <span><?= $order_data['billing']['address_2'] ?></span>
                </p>
                <p>
                    <span>الحي </span>
                    <span>الصحافة</span>
                </p>
                <p>
                    <span>رقم الطلب </span>
                    <span><?= $order->get_order_number() ?></span>
                </p>
                <p>
                    <span><?= __('Order status' , 'shiaka-emails') ?></span>
                    <span><?= $order->get_status() ?></span>
                </p>
            </div>
            <div class="col company">
                <h4><?= __('Company details' , 'shiaka-emails') ?></h4>
                <div class="info info-company">
                    <p><?= bloginfo('site_title') ?></p>
                    <p><?= __('Saudia arabia' , 'shiaka-emails') ?></p>
                    <p><?= __('Mecca' , 'shiaka-emails') ?></p>
                    <p><?= __('customer@shiaka.com' , 'shiaka-emails') ?> </p>
                    <p><?= bloginfo('site_url') ?></p>
                </div>

                <div class="payment">
                    <h4 class="table-title"><?= __('Payments and Shipping methods' , 'shiaka-emails') ?></h4>
                    <p>
                        <span><?= __('Payment method' , 'shiaka-emails') ?></span>
                        <span><?= $order->get_payment_method_title() ?></span>
                    </p>
                    <p>
                        <span><?= __('Order status' , 'shiaka-emails') ?> </span>
                        <span><?= __("Shiped" , 'shiaka-emails') ?></span>
                    </p>
                </div>

            </div>
        </div>
        <div class="tables">
            <table class="table-border">
                <tr>
                    <th><?= __('Totoal' , 'shikak-emails') ?></th>
                    <th><?= __("Tax" , 'shiaka-emails') ?></th>
                    <th><?= __('Price afrer discount' , 'shiaka-emails') ?></th>
                    <th><?= __('Discount' , 'shiaka-emails') ?></th>
                    <th> <?= __('Product price' , 'shiaka-emails') ?> </th>
                    <th><?= __('Qountity' , 'shiaka-emails') ?></th>
                    <th><?= __('Product' , 'shiaka-emails') ?></th>
                    <th> <?= __('Product nummber') ?>  </th>
                </tr>
                <tr>
<!--                    Get order items-->
                    <td><?=$order_data['total']  ?></td>
                    <td><?= $order_data['total_tax'] ?></td>
                    <td><?=  $order_data['discount_tax'] ?></td>
                    <td><?=  $order_data['total_tax'] ?></td>
                    <td>140.00</td>
                    <td>2</td>
                    <td>ثوب الشياكة كريم كلاسيك للرجال و الشباب
                    </td>
                    <td>65000000220000</td>

                </tr>
            </table>
            <table class="table-border">
                <tr>
                    <td><?= __('Total product before tax') ?></td>
                    <td><?= $order_data['total_tax'] ?></td>
                </tr>
                <tr>
                    <td><?=  $order->get_payment_method_title() ?></td>
                    <td><?=  $order_data['shipping_total'] ?></td>
                </tr>
                <tr>
                    <td><?= __('Total VAT' , 'shiaka-emails') ?></td>
                    <td><?=  $order_data['discount_tax'] ?></td>
                </tr>
                <tr>
                    <td><?= __('Totla' , 'shiaka-emails') ?></td>
                    <td><?=$order_data['total']  ?></td>
                </tr>
            </table>
        </div>
        <div class="content-footer">
            <h4>Alshiaka inc</h4>
        </div>
    </div>
<?php
/**
 * Hook for the woocommerce_email_order_details.
 *
 * @hooked WC_Emails::order_details() Shows the order details table.
 * @hooked WC_Structured_Data::generate_order_data() Generates structured data.
 * @hooked WC_Structured_Data::output_structured_data() Outputs structured data.
 * @since 2.5.0
 */
//do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

/**
 * Hook for the woocommerce_email_order_meta.
 *
 * @hooked WC_Emails::order_meta() Shows order meta data.
 */
//do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email );

/**
 * Hook for woocommerce_email_customer_details.
 *
 * @hooked WC_Emails::customer_details() Shows customer details
 * @hooked WC_Emails::email_address() Shows email address
 */
//do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email );

/**
 * Show user-defined additional content - this is set in each email's settings.
 */
// if ( $additional_content ) {
// 	echo wp_kses_post( wpautop( wptexturize( $additional_content ) ) );
// }

/**
 * Executes the email footer.
 *
 * @hooked WC_Emails::email_footer() Output the email footer
 */
//do_action( 'woocommerce_email_footer', $email );
