<?php 

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
  :root {
        --color-line: #eee
    }
    body{
        background: #eeeeee;
    }
    .container{
        background: white;
        width: 1170px;
        margin: 0 auto;
        padding: 9px;
    }

    .img-responsive {
        max-width: 100%;
        display: block;
        margin: 0 auto;
    }

    .logo {
        display: block;
        width: 39px;
        height: 39px;
    }

    .header {
        display: flex;
        flex-direction: column;
    }

    .content-footer{
        text-align: center;
    }

    .header .brand {
        display: flex;
        justify-content: space-around;
        align-items: center;
        width: 76.5%;
        margin: 0 auto;

    }
    .header .brand div:first-child{
        max-width: 25%;
    }
    .header .brand div:last-child{
        width: 20%;
    }
    .header .brand div:nth-child(2){
        width: 23%;
    }

    .header .brand img {
        display: block;
        margin: 0 auto;
        max-width: 100%;

    }

    .header .info {
        display: flex;
        justify-content: space-around;
        border: 1px solid  #eee;
        padding: 13px;
        width: 74%;
        margin: 0 auto;
    }

    .content-body {
        display: flex;
        justify-content: center;
        padding: 17px;
    }

    .content-body .col {
        width: 37%;
        border: 1px solid  #eee;
    }

    .content-body .client, .content-body .company {
        padding: 13px;
    }


    .content-body .client p {
        display: flex;
        justify-content: space-between;
    }

    table {
        border-collapse: collapse;
        width: 76.5%;
        margin: 15px auto;
    }
    table tr td , th{
        padding: 13px;
    }
    table tr td, th {
        border: 1px solid #eee;
    }
