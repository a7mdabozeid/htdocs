<?php
/**
 * Functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Razzi
 */


require_once get_template_directory() . '/inc/class-razzi-theme.php';
require_once get_template_directory() .'/khalil/CustomEdit.php';
\Khalil\CustomEdit::instance()->init();
\Razzi\Theme::instance()->init();


