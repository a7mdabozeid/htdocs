<?php 
namespace Khalil;
class StoreLocator {

   
protected static $instance = null;
 
private $api_key = "AIzaSyBHZponjI1kJysjIyyl4t7NzW52QiB8qfE"; 
private $callback = 'initMap'; 
public $lang  = "en";
private $src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyBdodiLO598_RD8_NYXK7nBKNA9Fhx_uBQ&language=en&libraries=places,geometry&.js";
	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object 
	 */ 

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}



    public function __construct()
    {
       is_rtl() ? $this->lang = 'ar' : $this->lang = 'en' ;   
      
       $this->init();
      
    }


    public function init() {
        add_action('wp_enqueue_scripts' , [$this , 'register_scripts']);
        $this->add_short_code();
    }

  public function add_short_code() {
       
     add_shortcode('shiaka-stores' , [$this , 'store_locator']);
  }  
 
  public function register_scripts() {
       $rtl = $this->lang  === "ar" ? '.rtl' : "";
       $rtl = trim($rtl);
       wp_register_style('shiaka-shortcode-storeslocaotr-css' , get_template_directory_uri()."/assets/storelocator/storelocator.min$rtl.css" ,  date("H-i-s"));
 
       wp_register_script('shiaka-map-api-js' , "https://maps.googleapis.com/maps/api/js?key=AIzaSyBdodiLO598_RD8_NYXK7nBKNA9Fhx_uBQ&language=$this->lang&libraries=places,geometry&.js" , null  , null , true);
       wp_register_script('shiaka-shortcode-storelocator-js' , get_template_directory_uri().'/assets/storelocator/jqury.storelocator.min.js' , ['jquery' ,'mastach-template'] , date("H-i-s") , true);
       wp_register_script('mastach-template' , get_template_directory_uri().'/assets/storelocator/handlebars.min.js' , [] , date("H-i-s") , true);
       wp_register_script('store-locator-app-js' , get_template_directory_uri().'/assets/storelocator/app.js' , ['jquery' , 'shiaka-shortcode-storelocator-js'] , date("H-i-s") , true);
   
    }

  public function store_locator(){

    // echo html 
    $ar = $this->lang === "ar" ? $this->lang :'';
    wp_localize_script('store-locator-app-js' ,'store_locator_data' , [
        'areas' =>  get_template_directory_uri().'/assets/storelocator/data/'.$this->lang.'.json',
        'path' =>  get_template_directory_uri().'/assets/storelocator/templates/'.$ar.'/'
    ]);
     
    $this->enuque_scripts();
     
     get_template_part('template-parts/store-locator/loc' ,'stores', [
      'locations' => \Khalil\Constant::get_stores_location()[is_rtl() ? "ar" : "en"]
     ]);
  }


  public function defer_scripts($tag,$handel,$src ) {
    $deffer_scripts_array = [
      'shiaka-map-api-js',
      //'shiaka-shortcode-stores-js'
    ];
    if(in_array($handel , $deffer_scripts_array)) {
      
      return '<script id="'.$handel.'" src="' . $src . '"></script>' . "\n";
    }
    return $tag ;
  }

  protected function enuque_scripts()
  {
    wp_enqueue_style('shiaka-shortcode-storeslocaotr-css');
    wp_enqueue_script('shiaka-map-api-js');
    wp_enqueue_script('shiaka-shortcode-storelocator-js');
    wp_enqueue_script('store-locator-app-js');
    
   // add_filter('script_loader_tag' , [$this , 'defer_scripts'] , 10 , 3);
  
  }
}