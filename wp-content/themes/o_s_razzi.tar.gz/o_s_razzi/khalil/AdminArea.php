<?php

namespace Khalil;

class AdminArea
{

    private static $instance = null;

    public static function instance()
    {
        if (self::$instance === null) return new self();

        return self::$instance;
    }


    public function __construct()
    {
        // add_action('submitpost_box', [$this, 'add_html']);

        // add_action('wp_loaded', [$this, 'delete_variatoons']);
    }

    protected function inject()
    {
        // add deelte vraiation  button on top of submut box
        // add_action('wp_load', [$this, 'delete_variatoons']);
    }


    public function delete_variatoons()
    {

        if ( $_REQUEST['action'] === 'edit' || $_REQUEST['action'] === 'editpost'
            && $_REQUEST['delete_va'] === 'delete'
            && $_REQUEST['post_type'] === 'product' ) {
            //  die(var_dump($_REQUEST));
            //die(var_dump(wc_get_product($_REQUEST['post'])));
            $id = $_REQUEST['post'];
            $product = wc_get_product($id);
            // check if product
            if (is_a($product , 'WC_Product') && is_a($product, 'WC_Product_Variable')) {
                // check if product has variations
                $data_store = new \WC_Product_Variable_Data_Store_CPT();

                $variations = $data_store->read_children($product); // return array of [all varaiatiosn ] [ only visable variations ]

                // Check if tehre is variation for product

                 if(is_array($variations) &&  empty($variations['all'] && count($variations['all']) <= 0)) {

                     add_action( 'admin_notices', [$this , 'sample_admin_notice__success'] );
                      //die(-1);
                     return ;
                 }
                // check if varaistion are visable

                if (!empty($variations['visible']) && count($variations['visible']) > 0) {
                    $data_store->delete_variations($id);

                    return;
                }

                // delete all varaitiosn even if not visable

                foreach ($variations['all'] as $variation) {

                    wp_trash_post($variation);
                }

                delete_transient('wc_product_children_' . $id);

            } //check of product is varaiable product onbject
        }
    }

    public function add_html()
    {
        ?>
        <div class="delete-button-container">
            <form method="POST" action="/">
                <input type="text" hidden name="delete_va" value="delete">
                <input style="margin:0 0 15px 0" class="button  button-primary button-large" name="delete_variation_cs" type="submit" value="delete All variation" placeholder="Delete">
            </form>
        </div>
        <?php
    }

    public function sample_admin_notice__success() {
        ?>
        <div class="notice notice-success is-dismissible">
                <p><?php _e( 'No variations!', 'sample-text-domain' ); ?></p>
        </div>
        <?php
    }

}






