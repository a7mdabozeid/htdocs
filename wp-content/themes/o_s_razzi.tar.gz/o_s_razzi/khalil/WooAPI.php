<?php

namespace Khalil;
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class WooAPI
{

    public function register_endpoint()
    {
      echo "string";

    }
}
