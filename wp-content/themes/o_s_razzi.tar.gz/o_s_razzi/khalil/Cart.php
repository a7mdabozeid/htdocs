<?php
namespace Khalil ;
class KHCart {
  
    public static $instance;

    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }

        return self::$instance;
    }



    public function __construct()
    {
        add_action('woocommerce_before_cart_totals' , [$this , 'add_html']);
        add_action('woocommerce_after_cart_table' , [$this , 'add_html']);
    }

    public function add_html() {
        ?>
          <div class="custom-box">
              <h1>Custom Data</h1> 
              <ul>
                  <li>Get products</li>
                  <li>Get cart product</li>
              </ul>   
          </div>
        <?php 
    }

}