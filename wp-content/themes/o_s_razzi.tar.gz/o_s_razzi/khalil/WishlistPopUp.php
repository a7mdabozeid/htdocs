<?php


namespace Khalil;
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}


class WishlistPopUp
{

    public static $instance;

    public function __construct()
    {
        add_action('wp_footer' , [$this , 'inject_html']);
    }


    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function inject_html()
    {
        get_template_part('template-parts/modals/wsl');
    }


}