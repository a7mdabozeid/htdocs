<?php

namespace Khalil;

use Razzi\AutoLoad;
use Razzi\Helper ;
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class CustomEdit
{
    protected static $instance = null;

    public function __construct()
    {
        // make autoloaed for dependany

        require_once(get_template_directory() . '/khalil/AutoLoadCustom.php');
        require_once get_template_directory() . '/inc/class-razzi-autoload.php';

        AutoLoadCustom::instance();
        AutoLoad::instance();
    }

    public static function instance() 
    {
        if (!is_null(self::$instance)) {
            return self::$instance;
        }
        return self::$instance = new self();
    }

 
    public function init()
    {  
         
        StoreLocator::instance();
        $this->register_objects();

    }

    public function register_objects()
    {

        //AdminArea::instance(); 
        // Fornt end
          Filters::instance()->init();
         CustomScripts::instance()->inject();
         CustomScripts::instance()->admin_inject();
         WishlistPopUp::instance();
         ProductPage::instance(); 
         CustomIcons::instance();
       AutoImageSwatchesImport::instance();
        Regions::instance();
        KHCart::instance();
    }



}

