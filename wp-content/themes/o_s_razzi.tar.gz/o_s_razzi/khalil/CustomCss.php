<?php

namespace Khalil;
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class CustomCss
{

    protected static $instance = null; 

    public function __construct()
    {
        //add_action('wp_head' , [$this , 'injectCssToHead']);
    }

    public static function instance()
    {
        return !is_null(self::$instance) ? self::$instance : new self();
    }

    public function init()
    {
        add_action('wp_head', [$this, 'injectCssToHead']);
    }

    public function injectCssToHead()
    {
        if (is_rtl()) {
            echo '<style>
         .razzi-button .razzi-svg-icon{
            transform: rotate(180deg) translateY(1.4px) translateX(10px) !important;
        }
       </style
     ';

        }

    }

}