<?php

namespace Khalil;
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class CustomScripts
{

    protected static $instance = null;

    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
            return self::$instance;
        }

        return self::$instance;
    }


    public function inject()
    {
        add_action('razzi_after_enqueue_style', [$this, 'inject_scripts']);
        add_action('wp_enqueue_scripts', [$this, 'register_scripts']);
    }

    public function admin_inject()
    {
        //
    }

    public function inject_scripts()
    {
       // $this->injcet_js();
        $this->register_styles();
    }


    public function register_styles()
    {
        $rtl = is_rtl() ? "custom-rtl.css" : 'custom.css';
        $ar = is_rtl() ? 'ar' :'';
        wp_enqueue_style('shiaka-custom-style', get_template_directory_uri() . '/new/css/' . $rtl, ['razzi-fonts'], rand(108 , 5098));
        wp_enqueue_style('overwirte_css', get_template_directory_uri() . '/assets/css/new/overwrite.css', ['razzi-fonts'], '1.0.0');

    }


    public function register_scripts()
    {
        
        if(class_exists('woocommerce')) {
            if(is_checkout())
            {
                wp_enqueue_script('shiaka-map-api-js');
                wp_add_inline_script('shiaka-map-api-js' , "
                function initialize() {
                    var input = document.querySelector('.autocomplete-selector-class input');
                    new google.maps.places.Autocomplete(input);
                  }
                  
                  google.maps.event.addDomListener(window, 'load', initialize);
                ");
            } 
        }
    }

   

   

}
// a short code to get products of category only for a spicifc tag;
// this short code will echo html conent (Object flush and object clean)
// this shortcode takes 2 argunets [cateogy(name , id , slug) , tags(array of tags keywords comma seperated )]
// use wordpreess query to query poruuct