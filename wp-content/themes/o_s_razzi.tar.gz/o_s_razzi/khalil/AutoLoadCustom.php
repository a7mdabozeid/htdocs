<?php

namespace Khalil;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class AutoLoadCustom
{

    protected static $instance = null;



    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct()
    {

        spl_autoload_register([$this, 'loadmMainDir']);
    }


    public function loadmMainDir($class)
    {
        $ext = ".php";
        $dir = get_template_directory() . '/khalil/';
        $file_name = preg_replace('/^' . __NAMESPACE__ . '\\\/', "", $class);
        $file = $dir . $file_name . $ext;
        if (is_readable($file)) {
            include($file);
        }
    }

    public function loadInc($class)
    {
        // Load inc folder @next when neaded;
    }
}