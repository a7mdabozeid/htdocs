<?php

namespace Khalil;
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class ShiakaCustomizer
{

    protected $instance = null;

    public $confing = [];

    public function __construct()
    {
        apply_filters('alshiaka_customize_confing' ,$this->confing);

    }



}