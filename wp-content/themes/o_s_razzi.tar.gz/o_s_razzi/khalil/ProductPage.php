<?php


namespace Khalil;
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}


class ProductPage
{

    public static $instance;

    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function __construct()
    {
        $this->shiaka_custmozier();
        $this->add_actions();
        $this->remove_actions();
    }



    public function remove_actions()
    {
        remove_action("woocommerce_before_add_to_cart_form",'tabby_product_promotion');
        add_action('woocommerce_after_add_to_cart_form','tabby_product_promotion');
    }
    public function shiaka_custmozier()
    {

        // add_filter('razzi_customize_sections', array($this, 'get_customize_sections'));
        // add_filter('razzi_customize_fields', array($this, 'get_customize_fields'));
    }
 

    public function get_customize_sections($sections)
    {
        $sections = array_merge($sections, [
            'product_page_carousal' => [
                'title' => esc_html('Product page carousal', 'razzi'),
                'priority' => 20,
                'panel' => 'woocommerce'
            ]
        ]);

        return $sections;
    }

    public function get_customize_fields($fields)
    {
        $fields = array_merge($fields, [
            'prodcut_carousal_location' => array(
                'type' => 'select',
                'label' => esc_html__('Chose where to show ', 'razzi'),
                'default' => '4',
                'section' => 'product_page_carousal',
                'priority' => 10,
                'choices' => array(
                    '1' => esc_html__('woocommerce_after_add_to_cart_form', 'razzi'),
                    '2' => esc_html__('woocommerce_share', 'razzi'),
                    '3' => esc_html__('woocommerce_product_thumbnails', 'razzi'),
                    '4' => esc_html__('woocommerce_after_single_product_summary', 'razzi'),

                ),
            )
        ]);
        return $fields;
    }

    public function add_actions()
    {
        // add_action('woocommerce_after_single_product_summary', [$this, 'shiaka_product_thumbnails']);
    }

    public function shiaka_after_single_product_summary()
    {
        var_dump("woocommerce_after_single_product_summary");
    }

    public function shiaka_product_thumbnails()
    {

        //        echo do_shortcode('[elementor-template id="41855"]');
        echo var_dump([
            'data' => "woocommerce_product_thumbnails",
            "WC" => class_exists('woocommerce')
        ]);
    }

    public function shiaka_share()
    {
        echo var_dump("woocommerce_share");
    }

    public function shiaka_after_add_to_cart_form()
    {
        echo var_dump('woocommerce_after_add_to_cart_form');
    }


}