<?php
/**
 * Template part for display cusrrencies
 *
 * @package Razzi
 */

?>
<div class="header-currencies">
	<?php \Razzi\Helper::currency_switcher(); ?>
</div><!-- .header-currencies -->
