<?php
/**
 * Template part for display primary menu
 * @todo: change nav hover sub in header
 * @todo: add banners to header
 * @todo: activate links on header
 * @todo: Marquee Header change color
 * @todo:overlay color on HERO slider image
 * @todo: change height of main header to ~90px
 *
 * @package Razzi
 */

 $classes = 'main-navigation primary-navigation';
if( \Razzi\Helper::get_option('header_active_primary_menu_color') == 'current' ) {
	$classes .= ' main-menu-current-color';
}
?>
<nav id="primary-menu" class="<?php echo esc_attr( $classes ); ?>">
	<?php \Razzi\Theme::instance()->get('header')->primary_menu(); ?>
</nav>
