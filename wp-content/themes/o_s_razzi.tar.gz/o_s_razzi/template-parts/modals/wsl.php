<div id="wslModal" class="rz-modal account-modal ra-account-modal" tabindex="-1" role="dialog">

    <div class="modal-header">
        <h3 class="modal-title"><?php esc_html_e( 'Wishlist', 'razzi' ) ?></h3>
        <a href="#" class="close-account-panel button-close"><?php echo \Razzi\Icon::get_svg( 'close' ); ?></a>
    </div>
    <div class="modal-content">
        <?php echo  do_shortcode('[yith_wcwl_wishlist]') ?>

    </div>
</div>