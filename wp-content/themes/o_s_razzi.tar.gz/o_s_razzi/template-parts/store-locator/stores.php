<?php

 die(var($args))
 $locations = isset($args['locations']) ? $args['locations'] : 'Variable vanish';
?>
<div id="store_locator" class="content-are">

    <div class="control">
        <select name="location" id="location">
            <?php if(is_array($locations)) {

              foreach($locations as $location) {
                
                ?>
                <option value="<?= $location ?>"><?=  $location?></option>
                <?php
              }
            } 
            ?>
        </select>
    </div>
    <div class="map-wrapper">
        <div id="kh_map"></div>
    </div>
</div>