<?php
/**
 * Template file for displaying search
 *
 * @package Razzi
 */
?>

<a href="#" class="rz-navigation-bar_icon search-icon" data-toggle="modal" data-target="search-modal">
	<?php echo \Razzi\Icon::get_svg( 'search', '', 'shop' ); ?>
</a>
