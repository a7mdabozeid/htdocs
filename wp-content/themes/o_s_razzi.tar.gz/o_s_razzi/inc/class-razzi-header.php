<?php
/**
 * Header functions and definitions.
 *
 * @package Razzi
 */

namespace Razzi;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Header initial
 *
 */
class Header
{
    /**
     * Instance
     *
     * @var $instance
     */
    protected static $instance = null;

    /**
     * Initiator
     *
     * @return object
     * @since 1.0.0
     */
    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Instantiate the object.
     *
     * @return void
     * @since 1.0.0
     *
     */
    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

        add_action('razzi_before_open_site_header', array($this, 'show_header_sticky_minimized'));

        add_action('razzi_after_open_site_header', array($this, 'show_header'));

        // Mobile
        add_action('razzi_after_open_site_header', array($this, 'mobile_header'), 99);

        add_filter('razzi_header_mobile_class', array($this, 'mobile_header_classes'));

        add_action('razzi_header_mobile_content', array($this, 'mobile_header_left'), 10);
        add_action('razzi_header_mobile_content', array($this, 'mobile_header_logo'), 30);
        add_action('razzi_header_mobile_content', array($this, 'mobile_header_icons'), 50);

        add_action('wp_footer', array($this, 'menu_mobile_modal'));

        add_action('wp_footer', array($this, 'menu_hamburger_modal'));
    }

    /**
     * Enqueue scripts and styles.
     *
     * @return void
     * @since 1.0.0
     *
     */
    public function enqueue_scripts()
    {
        wp_register_style('razzi-fonts', Helper::get_fonts_url(), array(), '20200928');

        $style_file = is_rtl() ? 'style-rtl.css' : 'style.css';
        wp_enqueue_style('razzi', apply_filters('razzi_get_style_directory_uri', get_template_directory_uri()) . '/' . $style_file, array(
            'razzi-fonts',
        ), '20211213');;

        do_action('razzi_after_enqueue_style');

        /**
         * Register and enqueue scripts
         */

        wp_enqueue_script('html5shiv', get_template_directory_uri() . '/assets/js/plugins/html5shiv.min.js', array(), '3.7.2');
        wp_script_add_data('html5shiv', 'conditional', 'lt IE 9');

        wp_enqueue_script('respond', get_template_directory_uri() . '/assets/js/plugins/respond.min.js', array(), '1.4.2');
        wp_script_add_data('respond', 'conditional', 'lt IE 9');

        wp_register_script('notify', get_template_directory_uri() . '/assets/js/plugins/notify.min.js', array(), '1.0.0', true);
        wp_register_script('swiper', get_template_directory_uri() . '/assets/js/plugins/swiper.min.js', array('jquery'), '5.3.8', true);
        wp_register_script('isInViewport', get_template_directory_uri() . '/assets/js/plugins/isInViewport.min.js', array(), '20201012', true);
        //wp_register_script("marquee", get_template_directory_uri() . '/assets/js/plugins/grouploop-1.0.3.min.js', ['jquery'], '1.0.3', true);
        $debug = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';
        wp_enqueue_script('razzi', get_template_directory_uri() . '/assets/js/scripts' . $debug . '.js', array(
            'jquery',
            'isInViewport',
            'swiper',
            'notify',
            'imagesloaded',
        ), '20211209', true);

        //wp_enqueue_script('custom', get_template_directory_uri() . '/assets/js/custom.js', ['jquery', 'marquee'], date("H:i:s"),true);

        if (is_singular() && comments_open() && get_option('thread_comments')) {
            wp_enqueue_script('comment-reply');
        }

        $razzi_data = array(
            'direction' => is_rtl() ? 'true' : 'false',
            'ajax_url' => class_exists('WC_AJAX') ? \WC_AJAX::get_endpoint('%%endpoint%%') : '',
            'nonce' => wp_create_nonce('_razzi_nonce'),
            'search_content_type' => Helper::get_option('header_search_type'),
            'header_search_number' => Helper::get_option('header_search_number'),
            'header_ajax_search' => intval(Helper::get_option('header_search_ajax')),
            'sticky_header' => intval(Helper::get_option('header_sticky')),
            'mobile_landscape' => Helper::get_option('mobile_landscape_product_columns'),
            'mobile_portrait' => Helper::get_option('mobile_portrait_product_columns'),
            'popup' => Helper::get_option('newsletter_popup_enable'),
            'popup_frequency' => Helper::get_option('newsletter_popup_frequency'),
            'popup_visible' => Helper::get_option('newsletter_popup_visible'),
            'popup_visible_delay' => Helper::get_option('newsletter_popup_visible_delay'),
        );

        $razzi_data = apply_filters('razzi_wp_script_data', $razzi_data);

        wp_localize_script(
            'razzi', 'razziData', $razzi_data
        );
        $custom_script_data = [
            'ajax_url' =>admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce('_custom_nonce'),

        ];
        wp_localize_script(
            'custom','customData' ,$custom_script_data
        );

    }

    /**
     * Display the site header sticky minimized
     *
     * @return void
     * @since 1.0.0
     *
     */

    public function show_header_sticky_minimized()
    {
        $show_header = is_page() ? !get_post_meta(\Razzi\Helper::get_post_ID(), 'rz_hide_header_section', true) : true;
        if (!apply_filters('razzi_get_header', $show_header)) {
            return;
        }

        if (!intval(Helper::get_option('header_sticky'))) {
            return;
        }

        if (get_post_meta(Helper::get_post_ID(), 'rz_header_background', true) == 'transparent') {
            return;
        }

        echo '<div id="site-header-minimized"></div>';
    }

    /**
     * Display the site header
     *
     * @return void
     * @since 1.0.0
     *
     */

    public function show_header()
    {

        $show_header = is_page() ? !get_post_meta(\Razzi\Helper::get_post_ID(), 'rz_hide_header_section', true) : true;
        if (!apply_filters('razzi_get_header', $show_header)) {
            return;
        }

        $custom_header_layout = get_post_meta(Helper::get_post_ID(), 'rz_header_layout', true);
        if (!empty($custom_header_layout) && 'default' != $custom_header_layout) {
            $this->prebuild_header($custom_header_layout);
        } else {
            if ('default' == Helper::get_option('header_type')) {
                $this->prebuild_header(Helper::get_option('header_layout'));
            } else {
                // Header main.
                $sections = array(
                    'left' => Helper::get_option('header_main_left'),
                    'center' => Helper::get_option('header_main_center'),
                    'right' => Helper::get_option('header_main_right'),
                );

                $classes = array('header-main', 'header-contents', 'hidden-md hidden-xs hidden-sm');

                $this->get_header_contents($sections, array('class' => $classes));

                // Header bottom.
                $sections = array(
                    'left' => Helper::get_option('header_bottom_left'),
                    'center' => Helper::get_option('header_bottom_center'),
                    'right' => Helper::get_option('header_bottom_right'),
                );

                $border = Helper::get_option('header_bottom_border_top');
                $border = $border ? 'has-border' : '';

                $sticky_bottom = in_array('header_main', (array)Helper::get_option('header_sticky_el')) ? 'rz-sticky-main' : '';

                $classes = array(
                    'header-bottom',
                    'header-contents',
                    'hidden-md hidden-xs hidden-sm',
                    $border,
                    $sticky_bottom
                );

                $this->get_header_contents($sections, array('class' => $classes));
            }
        }


    }

    /**
     * Display pre-build header
     *
     * @return void
     * @since 1.0.0
     *
     */
    protected function prebuild_header($version = 'v1')
    {
        switch ($version) {
            case 'v1':
                $main_sections = array(
                    'left' => array(
                        array('item' => 'logo'),
                    ),
                    'center' => array(
                        array('item' => 'menu-primary'),
                    ),
                    'right' => array(
                        array('item' => 'search'),
                        array('item' => 'account'),
                        array('item' => 'wishlist'),
                        array('item' => 'cart'),
                    ),
                );
                $bottom_sections = array();
                break;

            case 'v2':
                $main_sections = array(
                    'left' => array(
                        array('item' => 'menu-primary'),
                    ),
                    'center' => array(
                        array('item' => 'logo'),
                    ),
                    'right' => array(
                        array('item' => 'currencies'),
                        array('item' => 'languages'),
                        array('item' => 'search'),
                        array('item' => 'account'),
                        array('item' => 'wishlist'),
                        array('item' => 'cart'),
                    ),
                );
                $bottom_sections = array();
                break;

            case 'v3':
                $main_sections = array(
                    'left' => array(
                        array('item' => 'menu-secondary'),
                    ),
                    'center' => array(
                        array('item' => 'logo'),
                    ),
                    'right' => array(
                        array('item' => 'account'),
                        array('item' => 'wishlist'),
                        array('item' => 'cart'),
                    ),
                );
                $bottom_sections = array(
                    'left' => array(
                        array('item' => 'menu-primary'),
                    ),
                    'center' => array(),
                    'right' => array(
                        array('item' => 'search'),
                    ),
                );
                break;

            case 'v4':
                $main_sections = array(
                    'left' => array(
                        array('item' => 'logo'),
                    ),
                    'center' => array(
                        array('item' => 'menu-primary'),
                    ),
                    'right' => array(
                        array('item' => 'account'),
                        array('item' => 'wishlist'),
                        array('item' => 'cart'),
                    ),
                );
                $bottom_sections = array(
                    'left' => array(),
                    'center' => array(
                        array('item' => 'department'),
                        array('item' => 'search'),
                    ),
                    'right' => array(),
                );
                break;

            case 'v5':
                $main_sections = array(
                    'left' => array(
                        array('item' => 'logo'),
                    ),
                    'center' => array(),
                    'right' => array(
                        array('item' => 'search'),
                        array('item' => 'account'),
                        array('item' => 'wishlist'),
                        array('item' => 'cart'),
                        array('item' => 'hamburger'),
                    ),
                );
                $bottom_sections = array();
                break;

            case 'v6':
                $main_sections = array(
                    'left' => array(
                        array('item' => 'logo'),
                    ),
                    'center' => array(
                        array('item' => 'menu-primary'),
                    ),
                    'right' => array(
                        array('item' => 'socials'),
                    ),
                );
                $bottom_sections = array(
                    'left' => array(
                        array('item' => 'search'),
                    ),
                    'center' => array(),
                    'right' => array(
                        array('item' => 'account'),
                        array('item' => 'wishlist'),
                        array('item' => 'cart'),
                    ),
                );
                break;

            case 'v7':
                $main_sections = array(
                    'left' => array(
                        array('item' => 'logo'),
                    ),
                    'center' => array(),
                    'right' => array(
                        array('item' => 'menu-primary'),
                        array('item' => 'cart'),
                    ),
                );
                $bottom_sections = array();
                break;

            case 'v8':
                $main_sections = array(
                    'left' => array(
                        array('item' => 'menu-primary'),
                    ),
                    'center' => array(
                        array('item' => 'logo'),
                    ),
                    'right' => array(
                        array('item' => 'search'),
                        array('item' => 'account'),
                        array('item' => 'wishlist'),
                        array('item' => 'cart'),
                    ),
                );
                $bottom_sections = array();
                break;

            case 'v9':
                $main_sections = array(
                    'left' => array(
                        array('item' => 'logo'),
                    ),
                    'center' => array(
                        array('item' => 'search'),
                    ),
                    'right' => array(
                        array('item' => 'account'),
                        array('item' => 'wishlist'),
                        array('item' => 'cart'),
                    ),
                );
                $bottom_sections = array(
                    'left' => array(
                        array('item' => 'menu-primary'),
                    ),
                    'center' => array(),
                    'right' => array(),
                );
                break;

            default:
                $main_sections = array();
                $bottom_sections = array();
                break;
        }

        $classes = array('header-main', 'header-contents', 'hidden-xs hidden-sm');
        $this->get_header_contents($main_sections, array('class' => $classes));

        $classes = array('header-bottom', 'header-contents', 'hidden-xs hidden-sm');
        $this->get_header_contents($bottom_sections, array('class' => $classes));
    }

    /**
     * Display header items
     *
     * @return void
     * @since 1.0.0
     *
     */
    protected function get_header_contents($sections, $atts = array())
    {
        if (false == array_filter($sections)) {
            return;
        }

        $classes = array();
        if (isset($atts['class'])) {
            $classes = (array)$atts['class'];
            unset($atts['class']);
        }
        $logo = in_array('header-bottom', $classes) && !in_array('rz-sticky-main', $classes);
        if (empty($sections['left']) && empty($sections['right'])) {
            unset($sections['left']);
            unset($sections['right']);
        }

        if (!empty($sections['center'])) {
            $classes[] = 'has-center';
            $center_items = wp_list_pluck($sections['center'], 'item');

            if (in_array('logo', $center_items)) {
                $classes[] = 'logo-center';
            }

            if (in_array('menu-primary', $center_items)) {
                $classes[] = 'menu-center';
            }

            if (empty($sections['left']) && empty($sections['right'])) {
                $classes[] = 'no-sides';
            }
        } else {
            $classes[] = 'no-center';
            unset($sections['center']);

            if (empty($sections['left'])) {
                unset($sections['left']);
            }

            if (empty($sections['right'])) {
                unset($sections['right']);
            }
        }
        $attr = '';
        foreach ($atts as $name => $value) {
            $attr .= ' ' . $name . '=' . esc_attr($value) . '';
        }

        $container_width = 'container';

        if (Helper::get_header_layout() == 'v6') {
            $container_width = 'header-container';
        } elseif (Helper::get_option('header_width') == 'large') {
            $container_width = 'razzi-container';
        }

        ?>
        <div class="<?php echo esc_attr(implode(' ', $classes)); ?>" <?php echo esc_attr($attr); ?>>
            <div class="razzi-header-container <?php echo esc_attr(apply_filters('razzi_header_container_class', $container_width)); ?>">

                <?php foreach ($sections as $section => $items) : ?>
                    <?php
                    $class = '';
                    $item_names = wp_list_pluck($items, 'item');

                    if (in_array('menu-primary', $item_names)) {
                        $class .= ' has-menu';
                    }

                    if (in_array('language-currency', $item_names)) {
                        $class .= ' has-list-dropdown';
                    }


                    ?>
                    <div class="header-<?php echo esc_attr($section) ?>-items header-items <?php echo esc_attr($class) ?>">
                        <?php $this->get_header_items($items); ?>
                    </div>


                <?php endforeach; ?>
                <?php if ($logo) {
                    ?>
                    <div class="logo">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 37.13 37.18"><defs><style>.cls-1{fill:#14304f;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path id="Logo_icon" data-name="Logo icon" class="cls-1" d="M19.44,11.34c-1.66-.5-3.94-1-4.66-2.8a3.32,3.32,0,0,1-.22-1.33c0-.17.15-1,.32-1.1a3.3,3.3,0,0,1,1.49-.43C18.93,5.55,23.91,7.79,26.7,8l-3.87,4.22c-1.14-.26-2.27-.54-3.39-.88M33.28,2.66c1-1,2.1-1.57,2.43-1.24s0,.78-.4,1.43a5,5,0,0,1-1.05.79,4.08,4.08,0,0,1-1.82.41h-.25a6.29,6.29,0,0,1,1.09-1.4M31.11,14.48A34.7,34.7,0,0,0,26.3,13l8.58-7.85.47-.43h0C37,3.13,37.59,1.17,36.77.35S34,.18,32.4,1.78a6.29,6.29,0,0,0-.43.47L30.48,3.87c-3.06-.54-7.38-2.09-9.62-2a3.81,3.81,0,0,0-1.62.34,6.6,6.6,0,0,0-1.5,1c-1.23,1.08-2.26,2.18-3.92,3.87S10.94,10.21,11,11.61c.13,2.83,3.48,4,5.73,4.66.63.19,1.26.36,1.9.52l-3.18,3.47c-.24-.07-.49-.13-.73-.21-1.44-.43-3.52-1.2-3.6-3A3.42,3.42,0,0,1,12,14.49c-2.83,2.17-4.7,3.57-4.58,6,.1,2.22,2.12,3.38,4.07,4.06L0,37.13l4.19-3.85a5.46,5.46,0,0,1,2.09-1,7.4,7.4,0,0,1,3.77.43,63.77,63.77,0,0,1,6.83,3,10.58,10.58,0,0,0,5.27,1.39,8.52,8.52,0,0,0,4.73-2.35,20.56,20.56,0,0,0,3.76-4.24,9,9,0,0,1-6.07,2.21,15.13,15.13,0,0,1-5.71-1.94A23.25,23.25,0,0,0,13,28.44a7.37,7.37,0,0,0-3.7.2l0,0,3.9-3.58.51.13c.7.16,1.4.29,2.11.4a42.55,42.55,0,0,1,5.45,1.14c1.44.44,3.51,1.2,3.6,3a3.41,3.41,0,0,1-.87,2.57c2-1.5,4.71-3.22,4.58-6s-3.16-3.86-5.39-4.48l-.84-.21c-.7-.16-1.41-.29-2.12-.4s-1.57-.26-2.35-.41l3.68-3.37a50.39,50.39,0,0,1,5.15,1.3c3.53,1.18,6.33,3.89,5.78,7.89A7.56,7.56,0,0,1,31.24,30c2.72-2.33,5.53-5.4,5.35-9.23-.15-3.23-2.71-5.14-5.48-6.26"/></g></g></svg>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        <?php
    }

    /**
     * Display header items
     *
     * @return void
     * @since 1.0.0
     *
     */
    protected function get_header_items($items)
    {
        if (empty($items)) {
            return;
        }

        foreach ($items as $item) {
            if (!isset($item['item'])) {
                continue;
            }

            $item['item'] = $item['item'] ? $item['item'] : key($this->get_header_items_option());
            $template_file = $item['item'];

            switch ($item['item']) {
                case 'hamburger':
                    \Razzi\Theme::instance()->set_prop('modals', $item['item']);
                    break;

                case 'cart':
                    if (!class_exists('WooCommerce')) {
                        $template_file = '';
                        break;
                    }

                    if ('panel' == Helper::get_option('header_cart_behaviour')) {
                        \Razzi\Theme::instance()->set_prop('modals', $item['item']);
                    }

                    break;

                case 'search':
                    if ('icon' == Helper::get_option('header_search_style')) {
                        \Razzi\Theme::instance()->set_prop('modals', $item['item']);
                    }
                    break;

                case 'account':
                    if ('panel' == Helper::get_option('header_account_behaviour')) {
                        \Razzi\Theme::instance()->set_prop('modals', $item['item']);
                    }
                    break;
            }

            if ($template_file) {
                get_template_part('template-parts/headers/' . $template_file);
            }
        }
    }

    /**
     * Options of header items
     *
     * @return array
     * @since 1.0.0
     *
     */
    protected function get_header_items_option()
    {
        return apply_filters('razzi_header_items_option', array(
            '0' => esc_html__('Select a item', 'razzi'),
            'logo' => esc_html__('Logo', 'razzi'),
            'menu-primary' => esc_html__('Primary Menu', 'razzi'),
            'menu-secondary' => esc_html__('Secondary Menu', 'razzi'),
            'hamburger' => esc_html__('Hamburger Icon', 'razzi'),
            'search' => esc_html__('Search Icon', 'razzi'),
            'cart' => esc_html__('Cart Icon', 'razzi'),
            'account' => esc_html__('Account Icon', 'razzi'),
            'languages' => esc_html__('Languages', 'razzi'),
            'currencies' => esc_html__('Currencies', 'razzi'),
            'department' => esc_html__('Department', 'razzi'),
            'socials' => esc_html__('Socials', 'razzi'),
        ));
    }

    /**
     * Options of header items
     *
     * @return array
     * @since 1.0.0
     *
     */
    protected function get_mobile_header_icons_option()
    {
        return apply_filters('razzi_mobile_header_icons_option', array(
            'cart' => esc_html__('Cart Icon', 'razzi'),
            'wishlist' => esc_html__('Wishlist Icon', 'razzi'),
            'account' => esc_html__('Account Icon', 'razzi'),
            'menu' => esc_html__('Menu Icon', 'razzi'),
            'search' => esc_html__('Search Icon', 'razzi'),
        ));
    }

    /**
     * Get nav menu
     *
     * @return void
     * @since  1.0.0
     *
     */
    public function primary_menu($mega_menu = true)
    {
        $arrow_class = Helper::get_option('primary_menu_show_arrow') ? 'has-arrow' : '';
        $class = array('nav-menu', Helper::get_option('hamburger_click_item'), $arrow_class);
        $classes = implode(' ', $class);

        $primary_menu = get_post_meta(\Razzi\Helper::get_post_ID(), 'rz_header_primary_menu', true);
        $theme_location = $primary_menu ? '__no_such_location' : 'primary';

        if (empty($primary_menu) && !has_nav_menu($theme_location)) {
            return;
        }

        if ($mega_menu == true && Helper::get_header_layout() != 'v6' && class_exists('\Razzi\Addons\Modules\Mega_Menu\Walker')) {
            wp_nav_menu(apply_filters('razzi_navigation_primary_content', array(
                'theme_location' => $theme_location,
                'container' => false,
                'menu_class' => $classes,
                'menu' => $primary_menu,
                'walker' => new \Razzi\Addons\Modules\Mega_Menu\Walker()
            )));

        } else {
            wp_nav_menu(apply_filters('razzi_navigation_primary_content', array(
                'theme_location' => $theme_location,
                'container' => false,
                'menu_class' => $classes,
                'menu' => $primary_menu,
            )));
        }
    }

    /**
     * Display header extra class
     *
     * @return string
     * @since 1.0.0
     *
     */
    public static function classes($classes)
    {
        if (intval(Helper::get_option('header_sticky')) && Helper::get_header_layout() != 'v6') {
            $header_sticky_el = (array)Helper::get_option('header_sticky_el');

            if (Helper::get_option('header_type') == 'custom') {
                if (!in_array('header_main', $header_sticky_el)) {
                    $classes .= ' header-main-no-sticky';
                }

                if (!in_array('header_bottom', $header_sticky_el)) {
                    $classes .= ' header-bottom-no-sticky';
                }
            } else {
                if (in_array(Helper::get_option('header_layout'), array('v3', 'v4', 'v9'))) {
                    if (!in_array('header_main', $header_sticky_el)) {
                        $classes .= ' header-main-no-sticky';
                    }

                    if (!in_array('header_bottom', $header_sticky_el)) {
                        $classes .= ' header-bottom-no-sticky';
                    }
                } else {
                    $classes .= ' header-bottom-no-sticky';
                }
            }

        }

        if (!get_post_meta(\Razzi\Helper::get_post_ID(), 'rz_hide_header_border', true)) {
            $classes .= ' site-header__border';
        }

        echo esc_attr(apply_filters('razzi_site_header_class', $classes));
    }

    /**
     * Mobile header.
     *
     * @return void
     * @since 1.0.0
     *
     */
    public function mobile_header()
    {
        if (!apply_filters('razzi_get_header_mobile', true)) {
            return;
        }

        $show_header = is_page() ? !get_post_meta(\Razzi\Helper::get_post_ID(), 'rz_hide_header_section', true) : true;
        if (!$show_header) {
            return;
        }

        ?>
        <?php get_template_part('template-parts/mobile/header-mobile'); ?>

        <?php
    }

    /**
     * Mobile header classes
     *
     * @return string
     * @since 1.0.0
     *
     */
    public function mobile_header_classes($classes)
    {
        $mobile_logo = Helper::get_option('mobile_custom_logo') ? 'custom' : 'default';
        $classes .= ' header-contents';
        $classes .= ' logo-' . $mobile_logo;
        $classes .= ' hidden-md hidden-lg';

        if (!intval(Helper::get_option('mobile_menu_left'))) {
            $classes .= ' header-no-menu';
        }

        return $classes;
    }

    /**
     * Display mobile header icons
     *
     * @return void
     * @since 1.0.0
     *
     */
    public function mobile_header_icons()
    {
        $icons = Helper::get_option('mobile_header_icons');

        if (empty($icons)) {
            return;
        }

        echo ' <div class="mobile-header-icons">';

        foreach ($icons as $icon) {
            $icon['item'] = $icon['item'] ? $icon['item'] : key($this->get_mobile_header_icons_option());

            switch ($icon['item']) {
                case 'cart':
                    \Razzi\Theme::instance()->set_prop('modals', 'cart');
                    get_template_part('template-parts/headers/cart');
                    break;

                case 'wishlist':
                    get_template_part('template-parts/headers/wishlist');
                    break;

                case 'account':
                    \Razzi\Theme::instance()->set_prop('modals', 'account');
                    get_template_part('template-parts/headers/account');
                    break;

                case 'menu':
                    get_template_part('template-parts/mobile/header-menu');
                    break;

                case 'search':
                    \Razzi\Theme::instance()->set_prop('modals', 'search');
                    get_template_part('template-parts/mobile/header-search');
                    break;

                default:
                    do_action('razzi_mobile_header_icon', $icon['item']);
                    break;
            }
        }

        echo '</div>';
    }

    /**
     * Add menu mobile modal
     *
     * @return void
     * @since 1.0.0
     *
     */
    public function menu_mobile_modal()
    {
        ?>
        <div id="mobile-menu-modal"
             class="mobile-menu rz-modal ra-menu-mobile-modal ra-hamburger-modal side-left" tabindex="-1">
            <div class="off-modal-layer"></div>
            <div class="menu-mobile-panel-content panel-content">
                <div class="modal-header">
                    <div class="mobile-logo">
                        <?php if (Helper::get_option('mobile_panel_custom_logo')) : ?>
                            <?php get_template_part('template-parts/mobile/header-panel-logo'); ?>
                        <?php else : ?>
                            <?php get_template_part('template-parts/headers/logo'); ?>
                        <?php endif; ?>
                    </div>
                    <a href="#"
                       class="close-account-panel button-close"><?php echo \Razzi\Icon::get_svg('close'); ?></a>
                </div>
                <div class="modal-content">
                    <nav class="hamburger-navigation menu-mobile-navigation">
                        <?php

                        $class = array('nav-menu', 'menu', Helper::get_option('mobile_menu_click_item'));

                        $classes = implode(' ', $class);

                        $menu = has_nav_menu('mobile') ? 'mobile' : 'primary';

                        $arg = array(
                            'theme_location' => $menu,
                            'container' => null,
                            'fallback_cb' => 'wp_page_menu',
                            'menu_class' => $classes,
                        );

                        if (class_exists('\Razzi\Addons\Modules\Mega_Menu\Mobile_Walker')) {
                            $arg['walker'] = new \Razzi\Addons\Modules\Mega_Menu\Mobile_Walker();
                        }

                        wp_nav_menu($arg);
                        ?>
                    </nav>
                    <div class="content-footer">
                        <?php
                        if (intval(Helper::get_option('mobile_menu_show_socials'))) {
                            if (has_nav_menu('socials')) {
                                $args = array(
                                    'container' => 'div',
                                    'container_class' => 'topbar-socials-menu socials-menu',
                                    'theme_location' => 'socials',
                                    'menu_class' => 'menu',
                                    'link_before' => '<span>',
                                    'link_after' => '</span>',
                                );

                                if (class_exists('\Razzi\Addons\Modules\Mega_Menu\Socials_Walker')) {
                                    $args['walker'] = new \Razzi\Addons\Modules\Mega_Menu\Socials_Walker();
                                }

                                wp_nav_menu($args);
                            }
                        }

                        if (intval(Helper::get_option('mobile_menu_show_copyright'))) {
                            echo '<div class="menu-copyright">' . do_shortcode(wp_kses_post(Helper::get_option('footer_copyright'))) . '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Add Menu Hamburger Modal
     *
     * @return void
     * @since 1.0.0
     *
     */
    public function menu_hamburger_modal()
    {
        $modals = Theme::instance()->get_prop('modals');

        if (!in_array('hamburger', $modals)) {
            return;
        }

        ?>
        <div id="hamburger-modal"
             class="hamburger-modal rz-modal ra-hamburger-modal <?php echo esc_attr(Helper::get_option('hamburger_side_type') == 'side-left' ? 'side-left' : '') ?>"
             tabindex="-1" role="dialog">
            <div class="off-modal-layer"></div>
            <div class="hamburger-panel-content panel-content">
                <?php get_template_part('template-parts/modals/menu'); ?>
            </div>
        </div>
        <?php
    }

    /**
     * Get header mobile logo
     *
     * @return void
     * @since 1.0.0
     *
     */
    public function mobile_header_logo()
    {
        ?>
        <?php if (Helper::get_option('mobile_custom_logo')) : ?>
        <?php get_template_part('template-parts/mobile/header-logo'); ?>
    <?php else : ?>
        <?php get_template_part('template-parts/headers/logo'); ?>
    <?php endif; ?>
        <?php
    }

    /**
     * Get header mobile menu
     *
     * @return void
     * @since 1.0.0
     *
     */
    public function mobile_header_left()
    {
        if (is_front_page() || is_home()) {
            if (intval(Helper::get_option('mobile_menu_left'))) {
                get_template_part('template-parts/mobile/header-menu');
            }
        } else {
            if (!intval(Helper::get_option('mobile_header_history_back')) && intval(Helper::get_option('mobile_menu_left'))) {
                get_template_part('template-parts/mobile/header-menu');
            } elseif (intval(Helper::get_option('mobile_header_history_back'))) {
                get_template_part('template-parts/mobile/header-history-back');
            }
        }
    }


    /**
     * Display search quick links.
     *
     * @return void
     * @since 1.0.0
     *
     */
    public static function search_quicklinks($post_type = 'product')
    {
        if (!Helper::get_option('header_search_quick_links')) {
            return;
        }

        $links = (array)Helper::get_option('header_search_links');

        if (empty($links)) {
            return;
        }
        ?>
        <div class="quick-links">
            <p class="label"><?php esc_html_e('Quick Links', 'razzi'); ?></p>

            <ul class="links">
                <?php
                foreach ($links as $link) {
                    $url = $link['url'];

                    if (!$url) {
                        $query = array('s' => $link['text']);

                        if ($post_type) {
                            $query['post_type'] = $post_type;
                        }

                        $url = add_query_arg($query, home_url('/'));
                    }

                    printf(
                        '<li><a href="%s" class="underline-hover">%s</a>',
                        esc_url($url),
                        esc_html($link['text'])
                    );
                }
                ?>
            </ul>
        </div>
        <?php
    }

}
